# -----------------------------------------------------------------------------
# Copyright (c) 2026, Lucid Vision Labs, Inc.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
# BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
# ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# -----------------------------------------------------------------------------

import time
import ctypes

import numpy as np # pip3 install numpy
import cv2  # pip3 install opencv-python
from tkinter import * # pip3 install tk or 'sudo apt-get install python3-tk' for Linux

from arena_api.system import system
from arena_api.buffer import BufferFactory
from arena_api.enums import PixelFormat
from arena_api.__future__.save import Writer

'''
Helios-Chroma: Overlay
    This example shows how to overlay color image over 3D image using the
	Helios-Chroma device group. With the system calibrated, we can grab new images
    with the grouped Helios and Triton devices and use the calibration values from
    the device group to find the RGB color for each 3D point measured with the Helios.
    Based on the output of solvePnP, we can project the 3D points measured by
    the Helios onto the RGB camera image using the OpenCV function projectPoints.
    Grab a Helios image with the getImageHelios() function(output: xyz_mm) and
    a Triton RGB image with the getImageTriton() function(output: triton_rgb).
    The following code shows how to project the Helios xyz points onto the Triton
    image, giving a (row, col) position for each 3D point. We can sample the
    Triton image at that (row, col) position to find the 3D points RGB value.
'''

'''
Settings
'''

TAB1 = "  "
TAB2 = "    "

FILE_NAME = "images/py_helios_chroma_overlay/py_helios_chroma_overlay"
JPG = ".jpg"
PLY = ".ply"

TRITON = 'Triton'
HELIOS2 = 'Helios2'


'''
HELPERS
'''

def save_jpg(buffer, file_name):
    '''
    Save an image as Jpeg
    '''
    file_name = file_name + JPG
    print(f'{TAB2}Save image as .jpg to {file_name}')

    # convert image
    converted = BufferFactory.convert(buffer, PixelFormat.BGR8)

    # create a buffer writer
    writer_jpg = Writer.from_buffer(converted)

    writer_jpg.save(converted, file_name)
    

def save_ply(buffer_3d, file_name, color_data, scale=0.25, offset_x=0.0, offset_y=0.0, offset_z=0.0):
    '''
    Save an image as Ply
    '''
    file_name = file_name + PLY
    print(f'{TAB2}Save 3D image as .ply to {file_name}')

    # create a buffer writer
    writer_ply = Writer.from_buffer(buffer_3d)

    if (not color_data):
        writer_ply.save(buffer_3d, file_name,
					filter_points=True,
					scale=scale,
					offset_a=offset_x,
					offset_b=offset_y,
					offset_c=offset_z)
    else:
    	writer_ply.save(buffer_3d, file_name,
					color=color_data,
					filter_points=True,
					scale=scale,
					offset_a=offset_x,
					offset_b=offset_y,
					offset_c=offset_z)



class OverlayInfo:
    '''
    Holds the information needed to overlay depth and RGB images
    '''
    # Calibration values
    focal_length_x = 0.0
    focal_length_y = 0.0
    optical_center_x = 0.0
    optical_center_y = 0.0

    distortion_model = ""

    value0 = 0.0
    value1 = 0.0
    value2 = 0.0
    value3 = 0.0
    value4 = 0.0
    value5 = 0.0
    value6 = 0.0
    value7 = 0.0
  
    # Oritentation values
    rotation0 = 0.0
    rotation1 = 0.0
    rotation2 = 0.0

    translation_x = 0.0
    translation_y = 0.0
    translation_z = 0.0

    # Binning values
    binning_horizontal = 1
    binning_vertical = 1

    # 3D
    scale = 0.25
    coord_a = -8192.0
    coord_b = -8192.0
    coord_c = 0.0


def get_node_value_from_selector(node_map, selector_id, selector_value, node_id):
    node_map.get_node(selector_id).value = selector_value
    return node_map.get_node(node_id).value


def get_overlay_info_from_devices(device_triton, device_helios2):

    info = OverlayInfo()
    nodemap_triton = device_triton.nodemap
    nodemap_helios2 = device_helios2.nodemap

    # Calibration values, from Triton
    info.focal_length_x = nodemap_triton.get_node("CalibFocalLengthX").value
    info.focal_length_y = nodemap_triton.get_node("CalibFocalLengthY").value
    info.optical_center_x = nodemap_triton.get_node("CalibOpticalCenterX").value
    info.optical_center_y = nodemap_triton.get_node("CalibOpticalCenterY").value
    info.distortion_model = nodemap_triton.get_node("CalibLensDistortionModel").value

    info.value0 = get_node_value_from_selector(nodemap_triton, "CalibLensDistortionValueSelector", "Value0", "CalibLensDistortionValue")
    info.value1 = get_node_value_from_selector(nodemap_triton, "CalibLensDistortionValueSelector", "Value1", "CalibLensDistortionValue")
    info.value2 = get_node_value_from_selector(nodemap_triton, "CalibLensDistortionValueSelector", "Value2", "CalibLensDistortionValue")
    info.value3 = get_node_value_from_selector(nodemap_triton, "CalibLensDistortionValueSelector", "Value3", "CalibLensDistortionValue")
    info.value4 = get_node_value_from_selector(nodemap_triton, "CalibLensDistortionValueSelector", "Value4", "CalibLensDistortionValue")
    info.value5 = get_node_value_from_selector(nodemap_triton, "CalibLensDistortionValueSelector", "Value5", "CalibLensDistortionValue")
    info.value6 = get_node_value_from_selector(nodemap_triton, "CalibLensDistortionValueSelector", "Value6", "CalibLensDistortionValue")
    info.value7 = get_node_value_from_selector(nodemap_triton, "CalibLensDistortionValueSelector", "Value7", "CalibLensDistortionValue")

    # Orientation values, from Helios
    info.rotation0 = get_node_value_from_selector(nodemap_helios2, "DeviceGroupMemberTransformValueSelector", "RotationAxisAngleVector0", "DeviceGroupMemberTransformValue")
    info.rotation1 = get_node_value_from_selector(nodemap_helios2, "DeviceGroupMemberTransformValueSelector", "RotationAxisAngleVector1", "DeviceGroupMemberTransformValue")
    info.rotation2 = get_node_value_from_selector(nodemap_helios2, "DeviceGroupMemberTransformValueSelector", "RotationAxisAngleVector2", "DeviceGroupMemberTransformValue")
    info.translation_x = get_node_value_from_selector(nodemap_helios2, "DeviceGroupMemberTransformValueSelector", "TranslationX", "DeviceGroupMemberTransformValue")
    info.translation_y = get_node_value_from_selector(nodemap_helios2, "DeviceGroupMemberTransformValueSelector", "TranslationY", "DeviceGroupMemberTransformValue")
    info.translation_z = get_node_value_from_selector(nodemap_helios2, "DeviceGroupMemberTransformValueSelector", "TranslationZ", "DeviceGroupMemberTransformValue")

    # Binning values, from Triton
    info.binning_horizontal = nodemap_triton.get_node("BinningHorizontal").value
    info.binning_vertical = nodemap_triton.get_node("BinningVertical").value

    # 3D, from Helios
    info.scale = nodemap_helios2.get_node("Scan3dCoordinateScale").value
    info.coord_a = get_node_value_from_selector(nodemap_helios2, "Scan3dCoordinateSelector", "CoordinateA", "Scan3dCoordinateOffset")
    info.coord_b = get_node_value_from_selector(nodemap_helios2, "Scan3dCoordinateSelector", "CoordinateB", "Scan3dCoordinateOffset")
    info.coord_c = get_node_value_from_selector(nodemap_helios2, "Scan3dCoordinateSelector", "CoordinateC", "Scan3dCoordinateOffset")

    return info


def get_image_HLT(device):
    '''
    Returns intensity and xyz images from a Helios2 device
    '''
    # Set device stream nodemap --------------------------------------------
    tl_stream_nodemap = device.tl_stream_nodemap
    # Enable stream auto negotiate packet size
    tl_stream_nodemap['StreamAutoNegotiatePacketSize'].value = True
    # Enable stream packet resend
    tl_stream_nodemap['StreamPacketResendEnable'].value = True

    # Set nodes --------------------------------------------------------------
    nodemap = device.nodemap
    nodemap.get_node('PixelFormat').value = PixelFormat.Coord3D_ABCY16

    # Get node values ---------------------------------------------------------
    # Read the scale factor and offsets to convert from unsigned 16-bit values 
    # in the Coord3D_ABCY16 pixel format to coordinates in mm

        # "Coord3D_ABCY16s" and "Coord3D_ABCY16" pixelformats have 4
        # channels per pixel. Each channel is 16 bits and they represent:
        #   - x position
        #   - y postion
        #   - z postion
        #   - intensity

    # Get the coordinate scale in order to convert x, y and z values to millimeters as
    # well as the offset for x and y to correctly adjust values when in an
    # unsigned pixel format
    print(f'{TAB1}Get xyz coordinate scales and offsets from nodemap')
    xyz_scale_mm = nodemap["Scan3dCoordinateScale"].value # Coordinate scale to convert x, y, and z values to mm
    nodemap["Scan3dCoordinateSelector"].value = "CoordinateA"
    x_offset_mm = nodemap["Scan3dCoordinateOffset"].value # offset for x to adjust values when in unsigned pixel format
    nodemap["Scan3dCoordinateSelector"].value = "CoordinateB"
    y_offset_mm = nodemap["Scan3dCoordinateOffset"].value # offset for y
    nodemap["Scan3dCoordinateSelector"].value = "CoordinateC"
    z_offset_mm = nodemap["Scan3dCoordinateOffset"].value # offset for z

    # Start stream and get image
    device.start_stream()
    buffer = device.get_buffer()
    buffer_copy = BufferFactory.copy(buffer)

    # Get height and width
    height = int(buffer.height)
    width = int(buffer.width)
    channels_per_pixel = int(buffer.bits_per_pixel / 16)

    xyz_mm = np.zeros((height, width, 3), dtype=np.float32)
    intensity_image = np.zeros((height, width), dtype=np.uint16)

    # Get input data
    # Buffer.pdata is a (uint8, ctypes.c_ubyte) pointer.
    # This pixelformat has 4 channels, and each channel is 16 bits.
    # It is easier to deal with Buffer.pdata if it is cast to 16bits
    # so each channel value is read correctly.
    # The pixelformat is suffixed with "S" to indicate that the data
    # should be interpereted as signed. This one does not have "S", so
    # we cast it to unsigned.
    pdata_as_uint16 = ctypes.cast(buffer.pdata, ctypes.POINTER(ctypes.c_uint16))

    i = 0

    for ir in range(height):
        for ic in range(width):

            # Get unsigned 16 bit values for X,Y,Z coordinates
            x_u16 = pdata_as_uint16[i]
            y_u16 = pdata_as_uint16[i + 1]
            z_u16 = pdata_as_uint16[i + 2]

            # Convert 16-bit X,Y,Z to float values in mm
            xyz_mm[ir, ic][0] = float(x_u16 * xyz_scale_mm + x_offset_mm)
            xyz_mm[ir, ic][1] = float(y_u16 * xyz_scale_mm + y_offset_mm)
            xyz_mm[ir, ic][2] = float(z_u16 * xyz_scale_mm + z_offset_mm)

            intensity_image[ir, ic] = pdata_as_uint16[i + 3]

            i += channels_per_pixel


    # Stop stream
    device.requeue_buffer(buffer)
    device.stop_stream()

    return intensity_image, xyz_mm, height, width, buffer_copy


def get_image_TRI(device):
    '''
    Returns image from a Triton device
    '''
    # Set nodes --------------------------------------------------------------
    # - pixelformat to RGB8
    # - 3D operating mode
    nodemap = device.nodemap
    nodemap.get_node('PixelFormat').value = PixelFormat.RGB8

    # Set device stream nodemap --------------------------------------------
    tl_stream_nodemap = device.tl_stream_nodemap
    # Enable stream auto negotiate packet size
    tl_stream_nodemap['StreamAutoNegotiatePacketSize'].value = True
    # Enable stream packet resend
    tl_stream_nodemap['StreamPacketResendEnable'].value = True

    # Get image ---------------------------------------------------
    device.start_stream()
    buffer = device.get_buffer()
    buffer_copy = BufferFactory.copy(buffer)
    buffer_bytes_per_pixel = int(len(buffer.data)/(buffer.width * buffer.height))
    image_matrix = np.asarray(buffer.data, dtype=np.uint8)
    image_matrix_reshaped = image_matrix.reshape(buffer.height, buffer.width, buffer_bytes_per_pixel)

    # Stop stream -------------------------------------------------
    device.requeue_buffer(buffer)
    device.stop_stream()

    return image_matrix_reshaped, buffer_copy



'''
EXAMPLE
'''

def overlay_color_onto_3D_and_save(device_triton, device_helios2):
    
    # Get node values that will be changed in order to return their values at the end of the example --------------------
    nodemap_triton = device_triton.nodemap
    nodemap_helios2 = device_helios2.nodemap
    pixel_format_initial_triton = nodemap_triton.get_node("PixelFormat").value
    pixel_format_initial_helios2 = nodemap_helios2.get_node("PixelFormat").value

    print(f'{TAB1}Get and prepare information for overlay')

    overlay_info = get_overlay_info_from_devices(device_triton, device_helios2)

    # Calibration, camera matrix ----------------------------------------------------------------
    camera_matrix = np.zeros((3, 3), dtype=np.float64)
    camera_matrix[0, 0] = overlay_info.focal_length_x
    camera_matrix[0, 1] = 0.0
    camera_matrix[0, 2] = overlay_info.optical_center_x
    camera_matrix[1, 0] = 0.0
    camera_matrix[1, 1] = overlay_info.focal_length_y
    camera_matrix[1, 2] = overlay_info.optical_center_y
    camera_matrix[2, 0] = 0.0
    camera_matrix[2, 1] = 0.0
    camera_matrix[2, 2] = 1.0

    # Calibration, distortion coefficients ----------------------------------------------------------------
    dist_coeffs = np.zeros((8, 1), dtype=np.float64)
    dist_coeffs[0, 0] = overlay_info.value0
    dist_coeffs[1, 0] = overlay_info.value1
    dist_coeffs[2, 0] = overlay_info.value2
    dist_coeffs[3, 0] = overlay_info.value3
    dist_coeffs[4, 0] = overlay_info.value4
    dist_coeffs[5, 0] = overlay_info.value5
    dist_coeffs[6, 0] = overlay_info.value6
    dist_coeffs[7, 0] = overlay_info.value7

    # Orientation, rotation ----------------------------------------------------------------
    rotation_vector = np.zeros((3, 1), dtype=np.float64)
    rotation_vector[0, 0] = overlay_info.rotation0
    rotation_vector[1, 0] = overlay_info.rotation1
    rotation_vector[2, 0] = overlay_info.rotation2

    # Orientation, translation ----------------------------------------------------------------
    translation_vector = np.zeros((3, 1), dtype=np.float64)
    translation_vector[0, 0] = overlay_info.translation_x
    translation_vector[1, 0] = overlay_info.translation_y
    translation_vector[2, 0] = overlay_info.translation_z

    # Get an image from Triton ----------------------------------------------------------------
    print(f'{TAB1}Get, prepare and save Triton image')
    image_matrix_RGB, p_image_TRI = get_image_TRI(device_triton)

    print(f'{TAB2}Save Triton image matrix to {FILE_NAME + '_RGB.jpg'}')
    image_matrix_RGB_save = np.zeros(image_matrix_RGB.shape, dtype=np.uint8)
    cv2.cvtColor(image_matrix_RGB, cv2.COLOR_RGB2BGR, image_matrix_RGB_save)
    cv2.imwrite(FILE_NAME + '_RGB.jpg', image_matrix_RGB_save)

    save_jpg(p_image_TRI, FILE_NAME + '_triton')

    # Get an image from Helios2 ----------------------------------------------------------------
    print(f'{TAB1}Get, prepare and save Helios image')
    _, image_matrix_XYZ, height, width, p_image_HLT = get_image_HLT(device_helios2)

    print(f'{TAB2}Get xyz coordinate offsets and scale from helios nodemap')
    nodemap_helios2["Scan3dCoordinateSelector"].value = "CoordinateA"
    offset_x = nodemap_helios2["Scan3dCoordinateOffset"].value
    nodemap_helios2["Scan3dCoordinateSelector"].value = "CoordinateB"
    offset_y = nodemap_helios2["Scan3dCoordinateOffset"].value
    nodemap_helios2["Scan3dCoordinateSelector"].value = "CoordinateC"
    offset_z = nodemap_helios2["Scan3dCoordinateOffset"].value
    scale = nodemap_helios2["Scan3dCoordinateScale"].value
    save_ply(p_image_HLT, FILE_NAME + "_helios", False, scale=scale, offset_x=offset_x, offset_y=offset_y, offset_z=offset_z)

    # Overlay RGB color data onto 3D XYZ points -----------------------------------------------
    print(f'{TAB1}Overlay RGB color data onto 3D XYZ points')

    # Reshape image matrix
    # Convert the Helios xyz values from 640x480 to a Nx1 matrix to feed into projectPoints
    print(f'{TAB2}Reshape XYZ matrix')
    size = image_matrix_XYZ.shape[0] * image_matrix_XYZ.shape[1]
    xyz_points = np.reshape(image_matrix_XYZ, (size, 3))

    # Project points
    # Use projectPoints to find the position in the Triton image (row,col) of each Helios 3d point
    print(f'{TAB2}Project points')
    project_points_TRI, _ = cv2.projectPoints(xyz_points, rotation_vector, translation_vector, camera_matrix, dist_coeffs)

    # Finally, loop through the set of points and access the Triton RGB image at the positions
	# calculated by projectPoints to find the RGB value of each 3D point
    print(f'{TAB2}Get values at projected points')
    CustomArrayType = (ctypes.c_byte * (height * width * 3))
    color_data = CustomArrayType()

    for i in range(height * width):
        col_TRI = round(project_points_TRI[i][0][0])
        row_TRI = round(project_points_TRI[i][0][1])

        col_TRI /= overlay_info.binning_horizontal
        row_TRI /= overlay_info.binning_vertical
        col_TRI = round(col_TRI)
        row_TRI = round(row_TRI)

        # Only handle appropriate points
        if row_TRI < 0 or col_TRI < 0 or row_TRI >= image_matrix_RGB.shape[0] or col_TRI >= image_matrix_RGB.shape[1]:
            continue

        # Access corresponding XYZ and RGB data
        r_val = image_matrix_RGB[row_TRI, col_TRI][0]
        g_val = image_matrix_RGB[row_TRI, col_TRI][1]
        b_val = image_matrix_RGB[row_TRI, col_TRI][2]

        # Now you have the RGB values of a measured 3D Point at location (X,Y,Z).
		# Depending on your application you can do different things with these values,
		# for example, feed them into a point cloud rendering engine to view a 3D RGB image.
        color_data[i * 3] = r_val
        color_data[i * 3 + 1] = g_val
        color_data[i * 3 + 2] = b_val
        

    # Save result ----------------------------------------------------------------
    print(f'{TAB1}Save the resulting image')

    # Create p_color_data array
    p_color_data = (ctypes.c_ubyte * len(color_data)).from_address(ctypes.addressof(color_data))

    save_ply(p_image_HLT, FILE_NAME, color_data=p_color_data, scale=overlay_info.scale, offset_x=overlay_info.coord_a, offset_y=overlay_info.coord_b, offset_z=overlay_info.coord_c)

    # Return nodes to their original values ----------------------------------------------------------------
    nodemap_triton.get_node("PixelFormat").value = pixel_format_initial_triton
    nodemap_helios2.get_node("PixelFormat").value = pixel_format_initial_helios2


'''
PREPARATION
'''

def create_devices_with_tries():
    '''
    This function waits for the user to connect a device before raising
        an exception
    '''

    tries = 0
    tries_max = 6
    sleep_time_secs = 10
    while tries < tries_max:  # Wait for device for 60 seconds
        devices = system.create_device()
        if not devices:
            print(
                f'{TAB1}Try {tries+1} of {tries_max}: waiting for {sleep_time_secs} '
                f'secs for a device to be connected!')
            for sec_count in range(sleep_time_secs):
                time.sleep(1)
                print(f'{TAB1}{sec_count + 1 } seconds passed ',
                    '.' * sec_count, end='\r')
            tries += 1
        else:
            print(f'{TAB1}Created {len(devices)} device(s)')
            return devices
    else:
        raise Exception(f'{TAB1}No device found! Please connect a device and run '
                        f'the example again.')


def is_applicable_device_triton(device):
    '''
    Return True if a device is a Triton camera, False otherwise
    '''
    model_name = device.nodemap.get_node('DeviceModelName').value
    return "TRI" in model_name and "-C" in model_name


def is_applicable_device_helios2(device):
    '''
    Return True if a device is a Helios2 camera, False otherwise
    '''
    model_name = device.nodemap.get_node('DeviceModelName').value
    return "HLT" in model_name or "HT" in model_name 


def get_applicable_devices(devices, type):
    '''
    Return a list of applicable Triton or Helios devices
    '''
    applicable_devices = []

    for device in devices:
        if type == TRITON and is_applicable_device_triton(device):
            applicable_devices.append(device)
        elif type == HELIOS2 and is_applicable_device_helios2(device):
            applicable_devices.append(device)
    
    if not len(applicable_devices):
        raise Exception(f'{TAB1}No applicable device found! Please connect an Triton and Helios2 device and run '
                        f'the example again.')

    print(f'{TAB1}Detected {len(applicable_devices)} applicable {type} device(s)')
    return applicable_devices


def example_entry_point():
    
    print(f'{TAB1}py_helios_chroma_overlay')

    # Get connected devices ---------------------------------------------------
    # Create a device
    devices = create_devices_with_tries()

    # Filter applicable devices
    applicable_devices_triton = get_applicable_devices(devices, TRITON)
    applicable_devices_helios2 = get_applicable_devices(devices, HELIOS2)
    
    # Select a Triton camera to use
    device_triton = system.select_device(applicable_devices_triton)
    device_helios2 = system.select_device(applicable_devices_helios2)

    # Overlay color onto 3D and save ----------------------------------------
    overlay_color_onto_3D_and_save(device_triton, device_helios2)

    # Clean up ----------------------------------------------------------------
    '''
    Destroy device. This call is optional and will automatically be
        called for any remaining devices when the system module is unloading.
    '''
    system.destroy_device()
    print(f'{TAB1}Destroyed all created devices')
    

if __name__ == '__main__':
    print('Example started\n')
    example_entry_point()
    print('\nExample finished successfully')