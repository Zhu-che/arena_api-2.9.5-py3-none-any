# -----------------------------------------------------------------------------
# Copyright (c) 2026, Lucid Vision Labs, Inc.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
# BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
# ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# -----------------------------------------------------------------------------

import time

from arena_api.__future__.save import Writer
from arena_api.buffer import BufferFactory
from arena_api._overlay_info import OverlayInfo
from arena_api.enums import PixelFormat
from arena_api.system import system

'''
Helios-Chroma: Overlay SDK
    This example shows how to overlay color image over 3D image using the
	Helios-Chroma device group. With the system calibrated, we can grab new images
    with the grouped Helios and Triton devices and use the calibration values from
    the device group to find the RGB color for each 3D point measured with the Helios.
    The following code shows how to project the Helios xyz points onto the Triton
    image using ImageFactory of ArenaSDK.
'''

TAB1 = "  "
TAB2 = "    "

FILE_NAME = "images/py_helios_chroma_overlay_sdk/py_helios_chroma_overlay_sdk"
JPG = ".jpg"
PLY = ".ply"

TRITON = 'Triton'
HELIOS2 = 'Helios2'

PIXEL_FORMAT_3D = PixelFormat.Coord3D_ABCY16 # unsigned data
PIXEL_FORMAT = PixelFormat.RGB8  # color data


'''
PREPARATION
'''

def create_devices_with_tries():
    '''
    This function waits for the user to connect a device before raising
        an exception
    '''

    tries = 0
    tries_max = 6
    sleep_time_secs = 10
    while tries < tries_max:  # Wait for device for 60 seconds
        devices = system.create_device()
        if not devices:
            print(
                f'{TAB1}Try {tries+1} of {tries_max}: waiting for {sleep_time_secs} '
                f'secs for a device to be connected!')
            for sec_count in range(sleep_time_secs):
                time.sleep(1)
                print(f'{TAB1}{sec_count + 1 } seconds passed ',
                    '.' * sec_count, end='\r')
            tries += 1
        else:
            print(f'{TAB1}Created {len(devices)} device(s)')
            return devices
    else:
        raise Exception(f'{TAB1}No device found! Please connect a device and run '
                        f'the example again.')


def is_applicable_device_triton(device):
    '''
    Return True if a device is a Triton camera, False otherwise
    '''
    model_name = device.nodemap.get_node('DeviceModelName').value
    return "TRI" in model_name and "-C" in model_name


def is_applicable_device_helios2(device):
    '''
    Return True if a device is a Helios2 camera, False otherwise
    '''
    model_name = device.nodemap.get_node('DeviceModelName').value
    return "HLT" in model_name or "HT" in model_name 


def get_applicable_devices(devices, type):
    '''
    Return a list of applicable Triton or Helios devices
    '''
    applicable_devices = []

    for device in devices:
        if type == TRITON and is_applicable_device_triton(device):
            applicable_devices.append(device)
        elif type == HELIOS2 and is_applicable_device_helios2(device):
            applicable_devices.append(device)
    
    if not len(applicable_devices):
        raise Exception(f'{TAB1}No applicable device found! Please connect an Triton and Helios2 device and run '
                        f'the example again.')

    print(f'{TAB1}Detected {len(applicable_devices)} applicable {type} device(s)')
    return applicable_devices


'''
HELPERS
'''

def save_jpg(buffer, file_name):
    '''
    Save an image as Jpeg
    '''
    file_name = file_name + JPG
    print(f'{TAB2}Save image as .jpg to {file_name}')

    # convert image
    converted = BufferFactory.convert(buffer, PixelFormat.BGR8)

    # create a buffer writer
    writer_jpg = Writer.from_buffer(converted)

    writer_jpg.save(converted, file_name)
    

def save_ply(buffer_3d, file_name, color_data, scale, offset_x, offset_y, offset_z):
    '''
    Save an image as Ply
    '''
    file_name = file_name + PLY
    print(f'{TAB2}Save 3D image as .ply to {file_name}')

    # create a buffer writer
    writer_ply = Writer.from_buffer(buffer_3d)

    if (not color_data):
        writer_ply.save(buffer_3d, file_name,
					filter_points=True,
					scale=scale,
					offset_a=offset_x,
					offset_b=offset_y,
					offset_c=offset_z)
    else:
    	writer_ply.save(buffer_3d, file_name,
					color=color_data,
					filter_points=True,
					scale=scale,
					offset_a=offset_x,
					offset_b=offset_y,
					offset_c=offset_z)


'''
EXAMPLE
'''

def overlay_color_onto_3D_and_save(device_triton, device_helios2):
	#
	# Helios-Chroma: Overlay SDK
    # This example shows how to overlay color image over 3D image using the
	# Helios-Chroma device group. With the system calibrated, we can grab new images
	# with the grouped Helios and Triton devices and use the calibration values from
	# the device group to find the RGB color for each 3D point measured with the Helios.
	# The following code shows how to project the Helios xyz points onto the Triton
	# image using ImageFactory of ArenaSDK.
	#

    # Get node values that will be changed in order to return their values at the end of the example ----------------------------
    nodemap_triton = device_triton.nodemap
    nodemap_helios2 = device_helios2.nodemap
    pixel_format_initial_triton = nodemap_triton.get_node("PixelFormat").value
    pixel_format_initial_helios2 = nodemap_helios2.get_node("PixelFormat").value
	
	# Set triton device nodes ----------------------------------------------------------------
    nodemap_triton.get_node("OffsetX").value = 0
    nodemap_triton.get_node("OffsetY").value = 0
    nodemap_triton.get_node("Width").value = (nodemap_triton.get_node("Width")).max
    nodemap_triton.get_node("Height").value = (nodemap_triton.get_node("Height")).max
    nodemap_triton.get_node("BinningHorizontal").value = (nodemap_triton.get_node("BinningHorizontal")).max
    nodemap_triton.get_node("BinningVertical").value = (nodemap_triton.get_node("BinningVertical")).max
    
    print(f'{TAB1}Setting Triton pixel format to {PIXEL_FORMAT.name}')
    nodemap_triton.get_node('PixelFormat').value = PIXEL_FORMAT

	# Set Helios device nodes ----------------------------------------------------------------
    print(f'{TAB1}Setting Helios pixel format to {PIXEL_FORMAT_3D.name}')
    nodemap_helios2.get_node('PixelFormat').value = PIXEL_FORMAT_3D

	# Set device stream nodemap --------------------------------------------
    tl_stream_nodemap_tri = device_triton.tl_stream_nodemap
    # Enable stream auto negotiate packet size
    tl_stream_nodemap_tri['StreamAutoNegotiatePacketSize'].value = True
    # Enable stream packet resend
    tl_stream_nodemap_tri['StreamPacketResendEnable'].value = True

	# Get Triton image and save ----------------------------------------------------------------
    print(f'{TAB1}Get and save Triton image')
    device_triton.start_stream()
    buffer_tri = device_triton.get_buffer()
    
    save_jpg(buffer_tri, FILE_NAME + "_triton")

    # Set device stream nodemap --------------------------------------------
    tl_stream_nodemap_hlt = device_helios2.tl_stream_nodemap
    # Enable stream auto negotiate packet size
    tl_stream_nodemap_hlt['StreamAutoNegotiatePacketSize'].value = True
    # Enable stream packet resend
    tl_stream_nodemap_hlt['StreamPacketResendEnable'].value = True
    
	# Get Helios image and save ----------------------------------------------------------------
    print(f'{TAB1}Get and save Helios image')
    device_helios2.start_stream()
    buffer_hlt = device_helios2.get_buffer()
    
    print(f'{TAB2}Get xyz coordinate offsets and scale from helios nodemap')
    nodemap_helios2["Scan3dCoordinateSelector"].value = "CoordinateA"
    offset_x = nodemap_helios2["Scan3dCoordinateOffset"].value
    nodemap_helios2["Scan3dCoordinateSelector"].value = "CoordinateB"
    offset_y = nodemap_helios2["Scan3dCoordinateOffset"].value
    nodemap_helios2["Scan3dCoordinateSelector"].value = "CoordinateC"
    offset_z = nodemap_helios2["Scan3dCoordinateOffset"].value
    scale = nodemap_helios2["Scan3dCoordinateScale"].value
    
    save_ply(buffer_hlt, FILE_NAME + "_helios", False, scale=scale, offset_x=offset_x, offset_y=offset_y, offset_z=offset_z)
    
	# Get overlay information ----------------------------------------------------------------
    print(f'{TAB1}Get overlay information')
    overlay_info = BufferFactory.create_overlay_info(device_triton, device_helios2)
    
	# Overlay RGB color data onto 3D XYZ points and save the resulting image ----------------------------
    print(f'{TAB1}Overlay the RGB color data onto the 3D XYZ points and save')
    image_overlay = BufferFactory.overlay(buffer_hlt, buffer_tri, overlay_info)
    
    # Save the resulting image
    overlay_scale = OverlayInfo.get_scale(overlay_info)
    overlay_offset_a = OverlayInfo.get_coordinate_offset_a(overlay_info)
    overlay_offset_b = OverlayInfo.get_coordinate_offset_b(overlay_info)
    overlay_offset_c = OverlayInfo.get_coordinate_offset_c(overlay_info)

    save_jpg(image_overlay, FILE_NAME)
    save_ply(buffer_hlt, FILE_NAME, image_overlay.pdata, overlay_scale, overlay_offset_a, overlay_offset_b, overlay_offset_c)

	# Clean up ----------------------------------------------------------------
    device_triton.requeue_buffer(buffer_tri)
    device_helios2.requeue_buffer(buffer_hlt)
    device_triton.stop_stream()
    device_helios2.stop_stream()
    BufferFactory.destroy(image_overlay)
    BufferFactory.destroy_overlay_info(overlay_info)
    
	# Return nodes to their original values -----------------------------------
    nodemap_triton.get_node("PixelFormat").value = pixel_format_initial_triton
    nodemap_helios2.get_node("PixelFormat").value = pixel_format_initial_helios2

def example_entry_point():
    
    print(f'{TAB1}py_helios_chroma_overlay_sdk')

    # Get connected devices ---------------------------------------------------
    # Create a device
    devices = create_devices_with_tries()

    # Filter applicable devices
    applicable_devices_triton = get_applicable_devices(devices, TRITON)
    applicable_devices_helios2 = get_applicable_devices(devices, HELIOS2)
    
    # Select Triton and Helios cameras to use
    device_triton = system.select_device(applicable_devices_triton)
    device_helios2 = system.select_device(applicable_devices_helios2)

    # Overlay color onto 3D and save ----------------------------------------
    overlay_color_onto_3D_and_save(device_triton, device_helios2)

    # Clean up ----------------------------------------------------------------
    '''
    Destroy device. This call is optional and will automatically be
        called for any remaining devices when the system module is unloading.
    '''
    system.destroy_device()
    print(f'{TAB1}Destroyed all created devices')
    

if __name__ == '__main__':
    print('Example started\n')
    example_entry_point()
    print('\nExample finished successfully')