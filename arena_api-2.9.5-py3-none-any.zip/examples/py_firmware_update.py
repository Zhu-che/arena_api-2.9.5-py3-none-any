# -----------------------------------------------------------------------------
# Copyright (c) 2026, Lucid Vision Labs, Inc.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
# BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
# ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# -----------------------------------------------------------------------------

from pprint import pprint, PrettyPrinter
import json
import subprocess
from arena_api.system import system

'''
Firmware Updater
    This example demonstrates the built-in firmware updater function in Arena.
    The function requires the ip address and the file path to the firmware in
    order to update. The example begins by prompting the user to select a device,
    and then retrieves the ip address from the device infos as well as the firmware
    file path from the defined string constant below in settings. It then tries to
    run the firmware update via an exe call.
'''
TAB1 = "  "
TAB2 = "    "
FIRMWARE_PATH = "camera.fwa"

pp = PrettyPrinter()

def print_formatted_device_info(elem):
	if elem is not None:
		dict_str = json.dumps(elem, indent=2)
		formatted_str = ''.join([TAB2 + TAB1 + line for line in dict_str.splitlines(True)])
		print(formatted_str)

def select_device_info(device_infos):

	if isinstance(device_infos, list):
		if len(device_infos) == 0:
			raise ValueError('input can not be an empty list')
		elif not all(isinstance(d, dict) for d in device_infos):
			raise TypeError(f'Expected list of dictionary '
                            f'instead of {type(device_infos).__name__}')
	else:
		raise TypeError(f'Expected list of dictionary '
                        f'instead of {type(device_infos).__name__}')
			
	num_device_infos = len(device_infos)
	selection = 0
	
	if num_device_infos == 1:
		print_formatted_device_info(device_infos[0])
		print(f'{TAB2}Automatically selecting this device info.')
		return device_infos[0]
        
	print(f'{TAB1}Select device info:')
	for num, device_info in enumerate(device_infos):
		print(f'{TAB2}{num+1}.')
		print_formatted_device_info(device_info)
		
	while True:
		try:
			selection = int(input(TAB2 + 'Make selection (1-' + str(num_device_infos) + '): '))
		except ValueError:
			print(f'{TAB2}Invalid device info selected, please select a device in range.')
			continue

		if 0 < selection and selection <= num_device_infos:
			selected_device_info = device_infos[selection-1]
			break
		else:
			print(f'{TAB2}Invalid device info selected, please select a device in range.')

	return selected_device_info

def example_entry_point():

	# Discover devices --------------------------------------------------------

	print(f'{TAB1}Discover devices on network')
	device_infos = system.device_infos
	print(f'{TAB1}{len(device_infos)} devices found')

	if not device_infos:
		raise BaseException('No device is found!')

	# Choose a device for this example
	device_info = select_device_info(device_infos)

	ip_address = (device_info['ip'])
	firmware_path = FIRMWARE_PATH
	arguments = ["-i", ip_address, "-f", firmware_path] 

	executable_path = "LucidFirmwareUpdater_v140.exe" 
	command = [executable_path] + arguments

	# call FirmwareUpdater_v140.exe using subprocess
	try:
		result = subprocess.run(command, capture_output=True, text=True, check=True)

		# Print the output from the executable
		print("\n" + result.stdout)
	except subprocess.CalledProcessError as e:
		# Handle errors if the executable returns a non-zero exit code
		print(f"Error running executable: {e}")
		print(f"Return code: {e.returncode}")
		print(f"Output: {e.stdout}")
		print(f"Error output: {e.stderr}")
	except FileNotFoundError:
		print(f"Error: Executable not found at {executable_path}")
	except Exception as e:
		print(f"An unexpected error occurred: {e}")

	if FIRMWARE_PATH == "camera.fwa":
		print("Please edit the FIRMWARE_PATH constant at the top of this example to a valid firmware file!")

if __name__ == '__main__':
	print('\nWARNING:\nTHIS EXAMPLE MIGHT CHANGE THE DEVICE(S) SETTINGS!')
	print('\nExample started\n')
	example_entry_point()
	print('\nExample finished successfully')
