# -----------------------------------------------------------------------------
# Copyright (c) 2026, Lucid Vision Labs, Inc.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
# BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
# ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# -----------------------------------------------------------------------------

from pprint import pprint, PrettyPrinter
import json
import time
import ipaddress

from arena_api.system import system

'''
Set Persistent IP
    This example introduces device setting persistent IP and other settings.
    This is done by retrieving the initial IP address, subnet mask, and
    default gateway, then adding 1 to the ends of each octet, and setting
    the new values as our persistent IP/subnet/gateway. Then we reboot the
    device to demonstrate the changes, and then reset the device settings
    back to its initial state.
'''
TAB1 = "  "
TAB2 = "    "
TAB3 = "      "

wait_between_searches_time = 10

def add_one_to_info(info):
	octet0, octet1, octet2, octet3 = info.split('.')
	if octet3 == '254':  # Avoid 255
		octet3 = '1'
	else:
		octet3 = str(int(octet3) + 1)
	return f'{octet0}.{octet1}.{octet2}.{octet3}'

pp = PrettyPrinter()

def print_formatted_device_info(elem):
	if elem is not None:
		dict_str = json.dumps(elem, indent=2)
		formatted_str = ''.join([TAB2 + TAB1 + line for line in dict_str.splitlines(True)])
		print(formatted_str)

def example_entry_point():

	# Discover devices --------------------------------------------------------

	print(f'{TAB1}Discover devices on network')
	device_infos = system.device_infos
	print(f'{TAB1}{len(device_infos)} devices found')

	if not device_infos:
		raise BaseException('No device is found!')

	'''
	Get device information
    	This example grabs the IP address, subnet mask, and default
        gateway to display changes and return the device to its
        original IP address.
	'''

	devices = system.create_device()
	print(f'{TAB1}{len(devices)} devices found')

	device = system.select_device(devices)
	nodemap = device.nodemap

	device_serial = nodemap.get_node("DeviceSerialNumber").value
	
	ip = ipaddress.IPv4Address(nodemap.get_node("GevCurrentIPAddress").value)
	subnet = ipaddress.IPv4Address(nodemap.get_node("GevCurrentSubnetMask").value)
	gateway = ipaddress.IPv4Address(nodemap.get_node("GevCurrentDefaultGateway").value)
	
	print(f'{TAB1}Current IP = ', ip)
	print(f'{TAB1}Current subnet mask = ', subnet)
	print(f'{TAB1}Current default gateway = ', gateway)

	new_ip = add_one_to_info(str(ip))
	new_subnet = add_one_to_info(str(subnet))
	new_gateway = add_one_to_info(str(gateway))

	'''
	Set persistent IPs
		Set the node values of persistent IP/Subnet/Gateway to be the original
	    values but with 1 added to the last octet, then print out values
	'''
	new_ip_address = ipaddress.IPv4Address(new_ip)
	new_subnet_mask = ipaddress.IPv4Address(new_subnet)
	new_default_gateway = ipaddress.IPv4Address(new_gateway)

	print(f"{TAB1}Change persistent IP address to {new_ip_address}")
	nodemap.get_node("GevPersistentIPAddress").value = int(new_ip_address)

	print(f"{TAB1}Change persistent subnet mask to {new_subnet_mask}")
	nodemap.get_node("GevPersistentSubnetMask").value = int(new_subnet_mask)

	print(f"{TAB1}Change persistent default gateway to {new_default_gateway}")
	nodemap.get_node("GevPersistentDefaultGateway").value = int(new_default_gateway)

	print(f"{TAB1}Persistent IP configuration enabled")
	nodemap.get_node("GevCurrentIPConfigurationPersistentIP").value = True

	nodemap.get_node("DeviceReset").execute()
	print(f"{TAB1}Rebooting device")
	
	while (True):	
		print(f"{TAB1}Waiting for disconnect...")
		time.sleep(wait_between_searches_time)
		try:
			device.start_stream()
		except TimeoutError:
			# disconnected
			break
	
	system.destroy_device()

	# wait for reconnect
	while (True):
		found_device = False

		'''
		Get device infos, check for correct serial number
		'''
		print(f"{TAB1}Checking for device")
		device_infos = system.device_infos
		for device_info in device_infos:
			if ("serial", device_serial) in device_info.items():
				print(f"{TAB1}Found device")
				found_device = True
				break

		if found_device:
			devices = system.create_device()
			for device in devices:
				if device.nodemap.get_node("DeviceSerialNumber").value == device_serial:
					print(f"{TAB1}Connected device")
					break
			break
		else:
			print(f"{TAB1}Failed to find device")
			print(f"{TAB1}Waiting {wait_between_searches_time} seconds")
			time.sleep(wait_between_searches_time)
			print(f"{TAB1}Finished waiting")

	# Get device information again
	#    Notice that the MAC address, subnet mask, and default gateway all
	#    have been incremented by 1.
	device_info_new = {
		'mac': device_info['mac'],
		'ip': device_info['ip'],
		'subnetmask': device_info['subnetmask'],
		'defaultgateway': device_info['defaultgateway']
	}
	print(f'{TAB1}New IP = ', device_info_new['ip'])
	print(f'{TAB1}New subnet mask = ', device_info_new['subnetmask'])
	print(f'{TAB1}New default gateway = ', device_info_new['defaultgateway'])

	'''
	Reset device infos to initial values, then reboot device so they apply
	'''

	nodemap = device.nodemap

	nodemap.get_node("GevPersistentIPAddress").value = int(ip)
	nodemap.get_node("GevPersistentSubnetMask").value = int(subnet)
	nodemap.get_node("GevPersistentDefaultGateway").value = int(gateway)
	nodemap.get_node("GevCurrentIPConfigurationPersistentIP").value = True

	nodemap.get_node("DeviceReset").execute()

	print("Rebooting device (to reset settings)")

	while (True):	
		print(f"{TAB1}Waiting for disconnect...")
		time.sleep(wait_between_searches_time)
		try:
			device.start_stream()
		except TimeoutError:
			break

	system.destroy_device()
	print(f'{TAB1}Destroyed all created devices')

if __name__ == '__main__':
	print('\nWARNING:\nTHIS EXAMPLE MIGHT CHANGE THE DEVICE(S) SETTINGS!')
	print('\nExample started\n')
	example_entry_point()
	print('\nExample finished successfully')
