# -----------------------------------------------------------------------------
# Copyright (c) 2024, Lucid Vision Labs, Inc.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
# BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
# ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# -----------------------------------------------------------------------------

import time
from arena_api.enums import PixelFormat
from arena_api.__future__.save import Writer
from arena_api.system import system
from arena_api.buffer import BufferFactory
from arena_api._xlayer.xarena._xfilestream import _xIDevFileStream, _xODevFileStream

IMAGE_WIDTH = 300
IMAGE_HEIGHT = 300
TAB1 = '  '
TAB2 = '    '
PIXEL_FORMAT = PixelFormat.Mono8
MONO8_BITS_PER_PIXEL = 8
IMAGE_FILE_NAME = 'Images/Py_FileSystem_ReadAndWriteImage/image.jpg'

"""
Default camera file
	Some files have access restrictions (e.g., 'UserSet1', 'Firmware') and are usually not accessible
	for general read/write operations as they serve specific purposes. Typically, 'UserFile1' or similar
	files are intended for user usage.
"""
CAMERA_FILE = 'UserFile1'

'''
Filesystem: Read And Write Image
	This example demonstrates how to perform file read and write operations
	on the camera's local storage. Specifically, it illustrates how to capture
	an image from a data stream and save it to the camera's internal storage file.
'''


def create_devices_with_tries():
	'''
	This function waits for the user to connect a device before raising
		an exception
	'''

	tries = 0
	tries_max = 6
	sleep_time_secs = 10
	while tries < tries_max:  # Wait for device for 60 seconds
		devices = system.create_device()
		if not devices:
			print(
				f'Try {tries+1} of {tries_max}: waiting for {sleep_time_secs} '
				f'secs for a device to be connected!')
			for sec_count in range(sleep_time_secs):
				time.sleep(1)
				print(f'{sec_count + 1 } seconds passed ',
					'.' * sec_count, end='\r')
			tries += 1
		else:
			print(f'Created {len(devices)} device(s)')
			return devices
	else:
		raise Exception(f'No device found! Please connect a device and run '
						f'the example again.')


def write_data_to_camera_memory(nodemap, file_selection, data, data_size):
	
	# Get the available free size in camera's memory
	free_size = nodemap['FileStorageFreeSize'].value
	print(f"Camera file free size is: {free_size} Bytes")
	if free_size < data_size:
		print("File is too large for the local storage")
		return False

	stream = _xODevFileStream(nodemap, file_selection)
	print("Saving raw image to camera's local file (this may take some time for large buffer)")
	stream._acODevFileStreamWrite(data, data_size)
	
	if stream._acODevFileStreamFail():
		print("Stream failed during the write operation")
		return False
	
	print("Save raw image completed")
	stream._xODevFileStreamClose()
	return True

def read_and_save_from_camera_memory(nodemap, file_selection, data_size):
	try:
		stream = _xIDevFileStream(nodemap, file_selection)
		data = stream._acIDevFileStreamRead(data_size)
		
		# Check if stream read operation failed
		if stream._acIDevFileStreamFail():
			print("Stream failed during the read operation")
			return False

		# Create and save an image from the buffer data
		image_buffer = BufferFactory.create(data, data_size, IMAGE_WIDTH, IMAGE_HEIGHT, PIXEL_FORMAT)
		writer = Writer(image_buffer)
		writer.save(image_buffer, IMAGE_FILE_NAME)

		print(f"Image saved to {IMAGE_FILE_NAME}")
		BufferFactory.destroy(image_buffer)
		return True

	except Exception as e:
		print(f"Failed to read data from camera memory: {e}")
		return False


	
def file_system_read_and_write_image(device):
	nodemap = device.nodemap
	nodes = device.nodemap.get_node(['Width', 'Height', 'PixelFormat'])
	# Store initial settings, to restore later
	width_initial = nodes['Width'].value
	height_initial = nodes['Height'].value
	pixel_format_initial = nodes['PixelFormat'].value

	# Set features before streaming.-------------------------------------------
	nodes['Width'].value = IMAGE_WIDTH
	nodes['Height'].value = IMAGE_HEIGHT
	nodes['PixelFormat'].value = PIXEL_FORMAT

	with device.start_stream():
		print(f'\n{TAB1}Stream started with 1 buffer')
		print(f'{TAB1}Get a buffer')
		# get_buffer would timeout or return 1 buffers
		data_buffer = device.get_buffer()
		image_size = IMAGE_WIDTH * IMAGE_HEIGHT
  
  		# Write image data to camera memory
		print("Writing image data to camera memory")
		if not write_data_to_camera_memory(nodemap, CAMERA_FILE, data_buffer.pdata, image_size):
			raise RuntimeError("Failed to write image to camera memory")

		# Clear buffer and read image data back from camera memory
		print("Reading image data from camera memory")
		if not read_and_save_from_camera_memory(nodemap, CAMERA_FILE, image_size):
			raise RuntimeError("Failed to read image from camera memory")

		# Requeue the chunk data buffers
		device.requeue_buffer(data_buffer)
		print(f'{TAB1}Image buffer requeued')
  
	# When the scope of the context manager ends, then 'Device.stop_stream()'
	# is called automatically
	print(f'{TAB1}Stream stopped')

	# Clean up ----------------------------------------------------------------

	# restores initial node values
	nodemap['Width'].value = width_initial
	nodemap['Height'].value = height_initial
	nodemap['PixelFormat'].value = pixel_format_initial
	


def example_entry_point():

	# Get connected devices ---------------------------------------------------

	# Create a device
	devices = create_devices_with_tries()
	device = devices[0]
	print(f'Device used in the example:\n\t{device}')

	# Configure device and grab images ----------------------------------------

	file_system_read_and_write_image(device)

	# Clean up ----------------------------------------------------------------

	system.destroy_device()
	print('Destroyed all created devices')


if __name__ == '__main__':
	print('\nWARNING:\nTHIS EXAMPLE MIGHT CHANGE THE DEVICE(S) SETTINGS!')
	print('\nExample started\n')
	example_entry_point()
	print('\nExample finished successfully')